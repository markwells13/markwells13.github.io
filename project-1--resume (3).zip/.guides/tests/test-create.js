var walk = require('/home/codio/workspace/.guides/tests/test-walk.js');
var retStr = '';  

walk.walk('/home/codio/workspace/Project1-Resume', function(err, results) {
   retStr = '';     
   if (err) {
     process.stdout.write(err);
     process.exit(1);
   }

   if (results.indexOf('/home/codio/workspace/Project1-Resume/resume.html') == -1) {
     retStr += 'Could not find resume.html.\n';
   }
  
   if (retStr=='') {
     process.stdout.write('Well done!!!')
     process.exit(0);
   }
   else {
     process.stdout.write(retStr);
     process.exit(1);
   }
 });

